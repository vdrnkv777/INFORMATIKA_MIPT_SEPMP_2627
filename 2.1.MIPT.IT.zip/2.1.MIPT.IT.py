file_input = open('input.txt', 'r')
text = file_input.read()
file_input.close()

lines = text.split('\n')

chisla = lines[0].split()
a = int(chisla[0]) 
b = int(chisla[1]) 

operation = lines[1]

if operation == '+':
    result = a + b
elif operation == '-':
    result = a - b
elif operation == '*':
    result = a * b

otvet = "REZULTAT OPERAZII " + operation + " S CHISLAMI " + str(a) + " I " + str(b) + ":\n" + str(result)

file_output = open('output.txt', 'w')
file_output.write(otvet)
file_output.close()