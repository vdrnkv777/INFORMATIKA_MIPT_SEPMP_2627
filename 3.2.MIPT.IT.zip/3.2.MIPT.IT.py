file_input = open('input.txt', 'r')
text = file_input.read()
file_input.close()
N = int(text)
is_prosto = [True] * (N + 1)
if N >= 0:
    is_prosto[0] = False
if N >= 1:
    is_prosto[1] = False
for i in range(2, N + 1):
    if is_prosto[i] == True:
        for j in range(i * i, N + 1, i):
            is_prosto[j] = False
prostie = []
for i in range(2, N + 1):
    if is_prosto[i] == True:
        prostie.append(str(i))
result_text = "1, " + ", ".join(prostie)
file_output = open('output.txt', 'w')
file_output.write(result_text)
file_output.close()